#!/bin/bash
# Program:
# 
# Histroy
# ${DATE} ${USER} Firest release 
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin
export PATH
